window.onload = function(){
     $("body *").hide();
    $("body").append("<div class='alert alert-danger text-center' role='alert'><span class='glyphicon glyphicon-exclamation-sign'></span> 您的电脑的浏览器版本过低，无法正常访问领信空间。<a href='/linktrust/chrome.exe' class='btn btn-primary btn-sm' >下载谷歌浏览器</a></div>")
}